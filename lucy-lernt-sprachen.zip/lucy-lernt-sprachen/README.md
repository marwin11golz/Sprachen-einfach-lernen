# Lucy lernt Sprachen

Vokabeltrainer mit Spaced Repetition (SM-2), Lückensätzen für Konjugationen und Dashboard.

## Lokal ausführen
```bash
npm install
npm run dev
```
Dann die angezeigte Adresse (z. B. http://localhost:5173) im Browser öffnen.

## Online veröffentlichen (Vercel)
1. Dieses Projekt auf GitHub hochladen.
2. Auf vercel.com mit GitHub einloggen → "Add New Project" → dieses Repo auswählen → "Deploy".
3. Fertig – du bekommst eine öffentliche URL. Auf dem Handy: URL öffnen → "Zum Startbildschirm hinzufügen".
